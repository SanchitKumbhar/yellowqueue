import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.preprocessing import MinMaxScaler, StandardScaler

data = {
    'Student_Id': [101, 102, 103, 104, 105, 106, 107, 108, 109, 110],
    'Name': ['Alice', 'Bob', 'Charlie', 'David', 'Eva', 'Frank', 'Grace', 'Henry', 'Ivy', 'Jack'],
    'Age': [20, 21, 22, 20, 23, 21, -5, 20, 22, 24],         # -5 is an inconsistency (invalid age)
    'Gender': ['F', 'M', 'M', 'M', 'F', 'M', 'F', 'M', 'F', 'M'],
    'Math_Score': [85, 90, None, 78, 92, 88, 95, None, 70, 250],  # 250 is an outlier, None is missing
    'Science_Score': [78, None, 88, 74, 91, 85, 80, 82, None, 76],
    'English_Score': [82, 85, 90, None, 88, 79, 92, 86, 84, 81],
    'Attendance (%)': [95, 88, 92, 85, 78, 90, 96, 82, 87, 91],
    'Study_Hours_per_Week': [15, 20, 18, 12, 25, 17, 22, 14, 16, 50]  # 50 is an outlier
}

df = pd.DataFrame(data)
print(df.head())
print("\n\n")

# Mapping
df['Gender'] = df['Gender'].map({'M': 0, 'F': 1})
print(df)

print("\n\n")
# Normalization
df['Study_Hours_per_Week'] = StandardScaler().fit_transform(df[['Study_Hours_per_Week']])
print("Z-Score:\n", df['Study_Hours_per_Week'])

print("\n\n")
# Normalization
df['Study_Hours_per_Week'] = MinMaxScaler().fit_transform(df[['Study_Hours_per_Week']])
df['Study_Hours_per_Week']

print("\n\n")
# Handeled null values
print(df.isnull().sum())
df.fillna(df.mean(numeric_only=True), inplace=True)   # fill numeric with mean
df.fillna(df.mode().iloc[0], inplace=True)             # fill categorical with mode
print(df.isnull().sum())

print("\n\n")
print(df)