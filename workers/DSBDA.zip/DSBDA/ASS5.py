import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import MinMaxScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import confusion_matrix, classification_report

# Load dataset
df = pd.read_csv("Social_Network_Ads.csv")

print(df)

# Heatmap
sns.heatmap(df.corr(numeric_only=True), annot=True)
plt.show()

# Input and Output
X = df[['Age', 'EstimatedSalary']]
y = df['Purchased']

# Split data
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

# Normalization
scaler = MinMaxScaler()

X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

# Logistic Regression
model = LogisticRegression()
model.fit(X_train, y_train)

# Prediction
y_pred = model.predict(X_test)

# Confusion Matrix
cm = confusion_matrix(y_test, y_pred)

TN, FP, FN, TP = cm.ravel()

print("Confusion Matrix:")
print(cm)

print("\nAccuracy:", (TP + TN) / (TP + TN + FP + FN))
print("Error Rate:", (FP + FN) / (TP + TN + FP + FN))
print("Precision:", TP / (TP + FP))
print("Recall:", TP / (TP + FN))    

# Heatmap of confusion matrix
sns.heatmap(cm, annot=True, fmt='d')
plt.show()